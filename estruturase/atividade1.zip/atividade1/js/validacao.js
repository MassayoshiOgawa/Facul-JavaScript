function validaFormulario(){
    if(document.frmtstidade.numidade.value == ""){
        alert("Campo Idade é obrigatório!");
        document.frmtstidade.numidade.focus();
        return false;
    }
    if(document.frmtstidade.numidade.value >=18){
        alert("Você é maior de idade, pode entrar no site!");
        return true;
    }else{
        alert("Você é menor de idade, não pode entrar no site!");
        document.frmtstidade.numidade.focus();
        return false;
    }
}